import React from 'react';
import {PropTypes} from 'prop-types';
import { Route } from 'react-router-dom';
import {Activity} from './containers/Activity';

const ActivityRoute = ({ component: Component, ...rest }) => (
  <Route {...rest} render={props => (
        <Activity {...props}><Component {...props}/></Activity>
  )}/>
);

ActivityRoute.propTypes = {
  component: PropTypes.node
};

export default ActivityRoute;
