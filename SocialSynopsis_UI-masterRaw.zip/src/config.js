export const API_HOST = "http://api-syn.aadhya-analytics.com"; //"http://api-syn.aadhya-analytics.com";
export const API_HOST_SP = "http://api-sp.aadhya-analytics.com";
export const Alphabets = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "W", "X", "Y", "Z"];
export const token = '617570616468796179406161646879612d616e616c79746963732e636f6d';
export const twitter_screen_name = 'narendramodi';
