import React, { Component } from 'react';
import {Link,IndexLink} from 'react-router';

export default class LeftMenu extends Component {
  render() {
    return(
        <h1>Leftmenu</h1>
    );
  }
}
