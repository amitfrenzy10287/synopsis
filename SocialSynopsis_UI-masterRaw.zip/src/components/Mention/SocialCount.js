import React from 'react';
import {PropTypes} from 'prop-types';
import * as Icons from '../common/Icons';
   
 const SocialCount = ({like_count, reply_count, retweet_count }) => {
   return(
     <div className="rigght-commt-icone float-right">
         <span><img alt="Twitter likes" src={Icons.likeIcon} /> {like_count}</span>
         <span><img alt="Twitter share" src={Icons.shareIcon} /> {reply_count}</span>
         <span><img alt="Twitter comment" src={Icons.retweetIcon} /> {retweet_count}</span>
     </div>
   );
 };

 SocialCount.propTypes = {
   like_count: PropTypes.number,
   reply_count: PropTypes.number,
   retweet_count: PropTypes.number
 };

 export default SocialCount;
