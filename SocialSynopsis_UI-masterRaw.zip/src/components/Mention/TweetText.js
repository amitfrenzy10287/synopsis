import React from 'react';
import {PropTypes} from 'prop-types';
import SocialCount from './SocialCount';
import * as styles from './card-styles.css';
import ProfileImage from '../common/image';
import { Twemoji } from 'react-emoji-render';
import * as Emoticons from '../common/Emoticons';



const src="https://pbs.twimg.com/profile_images/718314968102367232/ypY1GPCQ_400x400.jpg";
var date = new Date(Date.now("dd-mm-yyyy")).toLocaleString();   

const TweetText = ({tweet_text, tweet_source, user_profile,
 tweet_created_at, mentioning_profile,reply_parent_tweet,reply_user_profile_image, like_count, reply_count,
  retweet_count, tweet_image, picture, facebook_coverphoto_url,sentiment, 
  message, facebook, share_count, comment_count, comment_message, 
  timestamp, story_tag_name, story, post_url, post_title, note_count,reply_to_user_text, 
  reply_text,reply_user_screen_name, reply_user_name, reply_parent_post_url, reply_parent_post_note_count,
   reply_parent_post_title}) => {
  const p_image  = mentioning_profile || user_profile || picture;
  
  return(
    <div className="row">
      <div className="userProfile">
            <ProfileImage image={src} class="rounded-circle" width="100px" />
      </div>
      <div className="panel tweetCardPanel col-md-10">
          <div className="padding-5 ">  
            <div className={tweet_text?"tweetCard":"tweetCard"}> 

              <div className="panel-body card-body">
                <div className="pull-left"> 
                  <ProfileImage image={tweet_image || reply_user_profile_image || facebook_coverphoto_url} class="profile_img" />
                </div>
                <p dangerouslySetInnerHTML={{ __html: tweet_text || message || reply_parent_tweet || comment_message || post_title || reply_text }}></p>
                {story && <p> <strong>Story: </strong>  {story} </p>}
                {reply_user_name && <p> <a href={reply_parent_post_url} target="_blank"> <strong>{reply_user_name}</strong> </a> </p>}
                {post_url && <p> <a href={post_url} target="_blank"> <strong>Post Link</strong> </a> </p>}
                {story_tag_name && <p> <strong>Story tag name: </strong>  {story_tag_name} </p>}
                {reply_parent_post_title && <p> <strong>Reply day count: </strong> {reply_parent_post_title}  {story} </p>}
                <span className="smile float-right"><img alt="Emoticons neutral" src={Emoticons.neutral} /> </span> 
              </div>
            <div className="com-like-box panel-footer">
              <span><strong>Published date</strong> : {date} </span>
              <SocialCount like_count={like_count} reply_count={reply_count || share_count} retweet_count={retweet_count || comment_count || note_count || reply_parent_post_note_count}/>
            </div>

            </div>

          </div>
        </div>
    </div> 
  );
};

TweetText.propTypes = {
  tweet_text: PropTypes.string,
  tweet_source: PropTypes.string,
  story_tag_name: PropTypes.string,
  story: PropTypes.string,
  post_url: PropTypes.string,
  post_title: PropTypes.string,
  note_count: PropTypes.string,
  reply_text: PropTypes.string,
  reply_user_name: PropTypes.string,
  reply_parent_post_url: PropTypes.string,
  reply_parent_post_note_count: PropTypes.string,
  reply_parent_post_title: PropTypes.string,
  user_profile: PropTypes.string,
  picture: PropTypes.string,
  tweet_created_at: PropTypes.string,
  mentioning_profile: PropTypes.string,
  like_count: PropTypes.number,
  reply_count: PropTypes.number,
  retweet_count: PropTypes.number,
  tweet_image: PropTypes.string,
  facebook_coverphoto_url: PropTypes.string,
  message: PropTypes.string,
  facebook: PropTypes.string,
  share_count: PropTypes.number,
  comment_count: PropTypes.number,
  comment_message: PropTypes.string,
  timestamp: PropTypes.string
};

export default TweetText;
